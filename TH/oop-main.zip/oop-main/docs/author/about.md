# Lecturer Infomation

---

## Lecturer
<div style="text-align: justify">

<a href="https://nd-hung.github.io">Dr. Hung Nguyen</a>, Deparment of Software Engineering, Faculty of Information Technology, Nha Trang University
<br>
Email: hungnd {at} ntu.edu.vn
</div>

## Acknowledgement
<div style="text-align: justify">
This document was built with <a href="https://mkdocs.org">MkDocs</a> and powered by <a href="https://github.com">GitHub</a>. 
</div>