# Mô hình hóa hướng đối tượng
---

## Sơ lược phân tích thiết kế hướng đối tượng

## Mô hình hóa hướng đối tượng với UML

## Tài liệu tham khảo
#### Object Oriented Analysis and Design using the UML, University of Calgary, 2000


