# .NET và C# #
---

## Nền tảng .NET

[.NET - do Microsoft phát triển](https://learn.microsoft.com/en-us/dotnet/) - là nền tảng lập trình miễn phí và mã nguồn mở. Với .NET có thể tạo 


## Ngôn ngữ lập trình C# ##

