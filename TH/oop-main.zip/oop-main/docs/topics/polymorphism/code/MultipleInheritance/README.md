# Minh họa đa thừa kế

![Multiple implementation](img/MultipleImplementation.png)