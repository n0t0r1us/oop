# Các chủ đề chính

---

## [Tổng quan](overview)
- Sơ lược các phương pháp lập trình
- Cách tiếp cận hướng đối tượng

## [Nền tảng .NET và ngôn ngữ C#](dotnet-and-csharp)
- Nền tảng .NET
- Ngôn ngữ C#

## [Lớp và đối tượng](classes-and-objects)
- Cài đặt lớp
- Đối tượng, thuộc tính và phương thức

## [Thừa kế](inheritance)
- Quan hệ tổng quát hóa, đặc biệt hóa
- Cài đặt lớp thừa kế

## [Đa hình](polymorphism)
- Dẫn nhập
- Cài đặt đa hình

## [Xử lý file](filehandling)
- Sơ lược về luồng (Streams)
- Xử lý file trong C#
