# Đa hình

Polymorphism

---

## 1 - [Animal](code/Animal/)
## 2 - [Ngăn xếp 2.0](code/Stack2/)