# Bài thực hành

Labs

---

## [0 - Thiết lập môi trường lập trình](00-installation)
## [1 - .NET và C#](01-dotnet-and-csharp)
## [2 - Lớp và đối tượng](02-classes-and-objects)
## [3 - Thừa kế](03-inheritance)
## [4 - Đa hình](04-polymorphism)
## [5 - Xử lý file](05-filehandling)
## [6 - Phát triển ứng dụng GUI](06-gui-development)
