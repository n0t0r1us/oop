# Thừa kế

Inheritance

---

## 1 - [Tạo lớp hình vuông](https://github.com/nd-hung/oop/tree/main/docs/topics/inheritance/code/Rectangle)

## 2 - [Tạo lớp sinh viên](https://github.com/nd-hung/oop/tree/main/docs/topics/inheritance/code/SinhVien)

## 3 - [Quản lý xe](code/QuanLyXe)

