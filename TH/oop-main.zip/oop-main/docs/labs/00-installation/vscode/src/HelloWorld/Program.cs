﻿/*
Hello from VS Code and .NET
*/
using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello from VS Code and .NET!");
        }
    }
}
