# Thiết lập môi trường lập trình C# #

---

## [Cài đặt Visual Studio](vs)

- Về Visual Studio
- Cài đặt Visual Studio
- Tạo ứng dụng C# với Visual Studio

## [Cài đặt Visual Studio Code](vscode) ##

- Về VS Code
- Cài đặt VS Code
- Tạo ứng dụng C# với VS Code

## [SplashKit](#)

- Về SplashKit
- Cài đặt
- Tạo ứng dụng đồ họa với C# và SplashKit
