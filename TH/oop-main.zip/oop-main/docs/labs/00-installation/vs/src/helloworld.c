// The first C program: print "Hello World!" message

int main()
{
	printf("Hello World!")
	return 0;
}






