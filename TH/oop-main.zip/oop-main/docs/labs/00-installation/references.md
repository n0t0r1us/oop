<h2 align="center"> 
Tài liệu tham khảo
</h2>

#### [Install Visual Studio](https://learn.microsoft.com/en-us/visualstudio/install/install-visual-studio?view=vs-2022)
#### [Learn to code in Visual Studio](https://visualstudio.microsoft.com/vs/getting-started/) 
#### [Visual Studio Code: Working with C#](https://code.visualstudio.com/docs/languages/csharp/) 
#### [Using .NET Core in Visual Studio Code](https://code.visualstudio.com/docs/languages/dotnet/) 
